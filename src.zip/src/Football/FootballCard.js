import React from "react"

export const FootballCard = () => (
    <section className="football">
        <h3 className="sport_name">Football</h3>
    </section>
)