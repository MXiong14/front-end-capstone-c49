import React from "react"

export const SoccerCard = () => (
    <section className="soccer">
        <h3 className="sport_name">Soccer</h3>
    </section>
)